package com.elastic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.elastic.model.Employee;
import com.elastic.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class EmployeeController {


	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/saveEmployee")
	public int saveEmployee(@RequestBody List<Employee> employee) {

    	log.info("Inside saveEmployee of EmployeeController");
		return employeeService.saveEmployee(employee);
	
	}

	@GetMapping("/findAll")
	public Iterable<Employee> findAllEmployees() {

    	log.info("Inside findAllEmployees of EmployeeController");
		return employeeService.findAllEmployees();
	}

	@GetMapping("/findByFName/{firstName}")
	public List<Employee> findByFirstName(@PathVariable String firstName) {

    	log.info("Inside findByFirstName of EmployeeController");
		return employeeService.findByFirstName(firstName);
	}

	
	
}
