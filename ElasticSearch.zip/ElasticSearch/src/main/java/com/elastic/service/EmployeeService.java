package com.elastic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.elastic.model.Employee;
import com.elastic.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	public int saveEmployee(@RequestBody List<Employee> employee) {

    	log.info("Inside saveEmployee of EmployeeService");
		employeeRepository.saveAll(employee);
		return employee.size();
	}

	public Iterable<Employee> findAllEmployees() {

    	log.info("Inside findAllEmployees of EmployeeService");
		return employeeRepository.findAll();
	}

	public List<Employee> findByFirstName(@PathVariable String firstName) {

    	log.info("Inside findByFirstName of EmployeeService");
		return employeeRepository.findByFirstname(firstName);
	}

	
}
