package com.elastic.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(indexName="employee",shards=2)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee  {
	
	@Id
	private String id;
	private String firstname;
	private String lastname;
	private int age;

}